/**
 * 
 */
package fengzhuangDemo;

/**
 * @author jiangpeifeng
 *
 */
public class Person {
	private String name;	// 姓名
	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
			this.name = name;
	}
	/**
	 * 
	 * @return
	 */
	public int getAge() {
		return age;
	}
	/**
	 * 
	 * @param age
	 */
	public void setAge(int age) {
		if(age <0 || age >200)
		{
			this.age = 0;
		}
		else {
			this.age = age;
		}
	}
	
	private int age;	// 年龄
	/**
	 * 
	 */
	public Person()
	{
		
	}
	/**
	 * 
	 * @param name
	 * @param age
	 */
	public Person(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	/**
	 * 
	 */
	public void showInfo()
	{
		System.out.print("姓名:"+ name +" ,年龄:"+age);
	}
}
