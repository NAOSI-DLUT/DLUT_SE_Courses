/**
 * 
 */
package fengzhuangDemo;

/**
 * @author jiangpeifeng
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p =new Person();
		p.setName("JPF");
		p.setAge(690);
		//p.age = 30;
		//p.name = "Mike";
		Person p2 = new Person("Mike",30);
		p.showInfo();
		p2.showInfo();
	}

}
