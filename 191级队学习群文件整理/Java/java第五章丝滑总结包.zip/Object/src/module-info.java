module Object {
}