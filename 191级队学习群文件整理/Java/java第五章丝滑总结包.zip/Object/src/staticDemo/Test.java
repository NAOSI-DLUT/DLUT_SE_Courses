/**
 * 
 */
package staticDemo;

/**
 * @author jiangpeifeng
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student("Anna",90);
		s1.showInfo();
		Student s2 = new Student("Tom",80);
		s2.showInfo();
	}
}
