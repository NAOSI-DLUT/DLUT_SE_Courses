/**
 * 
 */
package staticDemo;

/**
 * @author jiangpeifeng
 *
 */
public class Student {

	
		public String name;	// 姓名
		public int score;	// 分数
		public static int count = 0;	//  每构造一次，计数器加一,所有对象共享这个静态属性
		// 构造方法
		public Student(String name, int score)
		{
			this.name = name;	// 就近原则
			this.score = score;	
			count++;
		}
		
		public Student(int score)
		{
			name = "Mike";
			this.score = score;	
			count++;
		}
		
		// 输出信息
		public void showInfo()
		{
			System.out.println(name+"的成绩是"+score+",count="+count);
		}
	}

