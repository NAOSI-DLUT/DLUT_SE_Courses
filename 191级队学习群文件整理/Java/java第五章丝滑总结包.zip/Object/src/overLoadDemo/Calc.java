package overLoadDemo;

public class Calc {
	public int getSum(int num1, int num2)
	{
		return (num1+num2);
	}
	
	public double getSum(double num1, double num2)
	{
		return (num1 + num2);
	}
	
	public double getSum(double num1, double num2, double num3)
	{
		return (num1 + num2+num3);
	}
	
	public static void main(String[] args) {
		Calc cal = new Calc();
		System.out.println(cal.getSum(100,200));
		System.out.println(cal.getSum(10.5, 3.8));
		System.out.println(cal.getSum(10.5,3.8, 8.9));	
	}
}
