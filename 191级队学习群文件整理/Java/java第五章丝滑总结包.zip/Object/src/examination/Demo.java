package examination;

public class Demo {
	
		   private static int x ;
		   public static void main(String[] args){
		           System.out.println(x++);
		    }
		}

