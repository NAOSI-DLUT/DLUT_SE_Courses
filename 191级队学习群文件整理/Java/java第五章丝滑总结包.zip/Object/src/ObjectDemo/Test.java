/**
 * 
 */
package ObjectDemo;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String answer = "";
		do
		{
			Visitor v1 = new Visitor();
			System.out.print("请输入你的姓名：");
			v1.name = input.next();
			System.out.print("请输入你的年龄");
			v1.age = input.nextInt();
			v1.showPrice();
			System.out.print("是否继续？（y/n）");
			answer = input.next();
		}while(answer.equals("y"));
		System.out.println("谢谢惠顾，玩得愉快");
	}
}
