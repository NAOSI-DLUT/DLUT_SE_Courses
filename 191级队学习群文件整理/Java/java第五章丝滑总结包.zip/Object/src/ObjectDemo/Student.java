/**
 * 
 */
package ObjectDemo;

/**
 * @author jiangpeifeng
 *
 */
public class Student {
	public String name;	// 姓名
	public int score;	// 分数
	// 构造方法
	public Student(String name, int score)
	{
		this.name = name;	// 就近原则
		this.score = score;	
	}
	
	public Student(int score)
	{
		name = "Mike";
		this.score = score;	
	}
	
	// 输出信息
	public void showInfo()
	{
		System.out.println(name+"的成绩是"+score);
	}


}
