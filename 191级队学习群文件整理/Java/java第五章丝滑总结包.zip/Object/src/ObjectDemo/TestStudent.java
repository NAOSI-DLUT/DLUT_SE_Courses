/**
 * 
 */
package ObjectDemo;

/**
 * @author jiangpeifeng
 *
 */
public class TestStudent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student("Anna",90);
		Student s2 = new Student("Tom",80);
		Student s3 = new Student(100);
		s1.showInfo();
		s2.showInfo();
		s3.showInfo();
	}
}
