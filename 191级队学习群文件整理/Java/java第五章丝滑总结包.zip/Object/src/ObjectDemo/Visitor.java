package ObjectDemo;
/**
 * 游客类
 */

/**
 * @author jiangpeifeng
 *
 */
public class Visitor {
	public String name;	// 姓名
	public int age;	// 年龄
	/**
	 * 根据不同的年龄计算不同的门票价格
	 */
	public void showPrice()
	{
		if(age <= 10)
		{
			System.out.println("门票免费");
		}
		else if(age <= 60)
		{
			System.out.println("门票全价20元");
		}
		else
		{
			System.out.println("门票半价10元");
		}
	}

}
