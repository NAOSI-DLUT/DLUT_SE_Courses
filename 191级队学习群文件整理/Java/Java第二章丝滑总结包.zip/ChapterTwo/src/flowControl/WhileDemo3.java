/**
 * 
 */
package flowControl;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class WhileDemo3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String answer = "";
		Scanner input = new Scanner(System.in);
		System.out.print("合格了吗？（y/n）");
		answer = input.next();
		while("n".equals(answer))
		{
			System.out.println("上午阅读教材");
			System.out.println("下午上机编程");
			System.out.print("合格了吗？（y/n)");
			answer = input.next();
		}
		System.out.print("今天任务合格了");
	}

}
