/**
 * 
 */
package flowControl;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class JiechengDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		int result = 1;
		Scanner input = new Scanner(System.in);
		System.out.print("请输入一个正整数");
		n = input.nextInt();
		int sum =0;
		for(int i =1; i <= n;i++)
		{
			result *= i;
			sum += result;
		}
		System.out.println(n+"的阶乘是"+result);
		System.out.println("1+2!+3!+...+n!="+sum);
	}

}
