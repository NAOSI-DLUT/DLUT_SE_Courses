/**
 * 
 */
package flowControl;

import java.util.Scanner;

/**
 * @author jiangpeifeng
 *
 */
public class DoWhileDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String answer = "";	// 标识是否合格
		Scanner input = new Scanner(System.in);
		
		do
		{
			System.out.println("上机编程");
			System.out.print("合格了吗？（y/n)");
			answer = input.next();
		}while(!"y".equals(answer));
		System.out.print("今天任务合格了");
	}

}
