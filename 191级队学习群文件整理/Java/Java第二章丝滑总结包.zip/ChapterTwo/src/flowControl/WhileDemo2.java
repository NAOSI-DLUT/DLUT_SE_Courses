/**
 * 
 */
package flowControl;

/**
 * @author jiangpeifeng
 *
 */
public class WhileDemo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 1;
		while(count <= 500)
		{
			System.out.println("第"+count+"份试卷");
			count++;
		}
	}
}
