/**
 * 
 */
package flowControl;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class Sumtable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		Scanner input = new Scanner(System.in);
		System.out.print("请输入一个整数值");
		int val = input.nextInt();
		System.out.println("根据这个值可以输出如下加法表");
		for (i = 0, j = val; i <= val; i++, j-- ) 
		{
			System.out.println(i+"+"+j+"="+(i+j));
		}
	}
}
