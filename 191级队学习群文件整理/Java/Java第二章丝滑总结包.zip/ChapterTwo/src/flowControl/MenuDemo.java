/**
 * 
 */
package flowControl;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class MenuDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("欢迎使用本管理系统");
		System.out.println("1：登录系统 2：注册系统 3：退出 4：录入数据	");
		System.out.print("输入相应的数字进行使用：");
		Scanner input = new Scanner(System.in);
		if(input.hasNextInt() == true)
		{
			int num = input.nextInt();
			switch(num)
			{
			case 1:
				// 登录
				break;
			case 2:
				// 注册
				break;
			case 3:
				// 退出
				break;
			case 4:
				// 录入数据
				break;
			default:
				System.out.println("请输入正确的数字进行使用！");
				break;
			}
		}
		else
		{
			System.out.println("请输入正确的数字");
		}
	}

}
