/**
 * 
 */
package flowControl;

/**
 * @author jiangpeifeng
 *
 */
public class WhileDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		while(i <= 100)
		{
			System.out.println("第"+i+"遍"+"好好学习，天天向上");
			i++;
		}
	}

}
