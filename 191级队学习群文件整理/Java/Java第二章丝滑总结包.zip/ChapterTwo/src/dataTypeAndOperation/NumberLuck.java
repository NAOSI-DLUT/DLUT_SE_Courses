/**
 * 
 */
package dataTypeAndOperation;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class NumberLuck {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int custNo;	// 会员号
		System.out.print("请输入四位会员卡号：");
		Scanner input = new Scanner(System.in);
		custNo = input.nextInt();
		
		int gewei = custNo % 10;	// 得到的个位数
		int shiwei = custNo / 10 % 10;	// 得到的十位数
		int baiwei = custNo / 100 % 10;	// 得到百位数
		int qianwei = custNo / 1000 ;	// 得到千位数
		
		int sum = gewei + shiwei + baiwei + qianwei;	// 计算数字之和
		boolean isLuck = sum > 20;
		System.out.print("幸运用户"+isLuck);
	}

}
