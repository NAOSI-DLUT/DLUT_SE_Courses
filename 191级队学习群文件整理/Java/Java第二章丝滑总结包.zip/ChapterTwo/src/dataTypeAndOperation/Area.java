/**
 * 
 */
package dataTypeAndOperation;


import java.util.*;

/**
 * @author jiangpeifeng
 *
 */
public class Area {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double PI = Math.PI;
		System.out.print("请输入半径值：");
		Scanner input = new Scanner(System.in);
		double radius = input.nextDouble();	// 读入用户输入的半径
		double area = radius * radius * PI;
		System.out.println("圆的面积是" + area);
	}
}
