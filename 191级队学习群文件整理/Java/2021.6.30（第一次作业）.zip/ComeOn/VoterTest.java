package ComeOn;

import javax.swing.JOptionPane;

;public class VoterTest 
{
    public static int[] box = new int[3]; 
    public static int JPF = 0;
    public static int KYX = 0;
    public static int DHT = 0;
    public static Voter[] voter = new Voter[5];
    public static void simulationVoter() 
    {
        // 模拟选民投票
        for(int i = 0; i < 3; i++)
        {
            // 生成选民
            voter[i] = new Voter();
            voter[i].setVoteID(i);
            // 开始投票
            voter[i].vote();
        }
    }

    // 计票
    public static void countBox()
    {
        for(int i = 0; i< 3; i++)
        {
             box[i] = voter[i].note;
             switch(box[i])
             {
                 case 1:
                    JPF++;
                    break;
                 case 2:
                    KYX++;
                    break;
                case 3:
                    DHT++;
                    break;
                default:
                 break;
             }
        }
    }

    // 输出
    public static void display()
    {
        String output = "投票结果为：";
        output += "\n姜沛峰："+JPF+" 票\n";
        output += "\n柯懿星："+KYX+" 票\n";
        output += "\n代昊天："+DHT+" 票\n";
        JOptionPane.showMessageDialog(null,output, "投票结果", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) 
    {
        simulationVoter();
        countBox();
        display();
    }
   
}




