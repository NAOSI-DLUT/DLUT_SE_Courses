package ComeOn;

import javax.swing.JOptionPane;


public class Voter {
    
    private  boolean flag;   // 是否完成投票
    private  int voteID;   //
    public  int note;
    public  Voter() 
    {
        flag = false;
    }

    public  boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public  int getVoteID() {
        return voteID;
    }
    public void  setVoteID(int num)
    {
        voteID = num;
    }
    /* 投票函数 */ 
    public void vote()
    {
            String output = "您已投票给：";
            if (voteID > 2)
            {
                JOptionPane.showConfirmDialog(null, "票箱已满，不能投票了！", "WARNING", JOptionPane.CANCEL_OPTION);
                flag = false;
            }
            else
            {
                String numString = JOptionPane.showInputDialog(null, "您要投票给谁？若姜沛峰请输入1；若柯懿星请输入2；若代昊天请输入3","投票中",JOptionPane.QUESTION_MESSAGE);
                note =  Integer.parseInt(numString);
                switch(note)
             {
                 case 1:
                    output += "姜沛峰\n";
                    break;
                 case 2:
                    output += "柯懿星\n";
                    break;
                case 3:
                    output += "代昊天\n";
                    break;
                default:
                 break;
             }
                JOptionPane.showMessageDialog(null, output, "投票成功"+voteID, JOptionPane.INFORMATION_MESSAGE);
                flag = true;
            }
        
    }
}

