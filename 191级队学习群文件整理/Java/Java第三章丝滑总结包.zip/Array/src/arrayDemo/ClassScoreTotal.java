/**
 * 
 */
package arrayDemo;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class ClassScoreTotal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] scores = new int[5][5];	// 第一个5代表5个班，第二个5代表每个5个班有
		Scanner input = new Scanner(System.in);
		// 为班级同学成绩赋值
		for(int i  = 0; i<scores.length;i++)
		{
			// 外层循环，班级在循环
			System.out.println("-------第"+(i+1)+"个班----------");
			for(int j = 0; j<scores[i].length;j++)
			{
				// 内层循环，每一个班级同学成绩
				System.out.println("请输入第"+(i+1)+"个班第" +(j+1)+"个同学的成绩：");
				scores[i][j] = input.nextInt();
			}
		}
		// 完成五个班级同学的成绩统计
		System.out.println("-------统计成绩--------");
		for(int i =0; i < scores.length;i++)
		{
			int sum = 0;
			for(int j = 0; j<scores[i].length; j++) 
			{
				sum += scores[i][j];
			}
			System.out.println("第"+(i+1)+"个班级的同学的总成绩为"+sum);
		}
	}

}
