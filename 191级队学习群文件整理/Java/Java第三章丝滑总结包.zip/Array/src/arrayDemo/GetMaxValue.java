/**
 * 
 */
package arrayDemo;

import java.util.Scanner;

/**
 * @author jiangpeifeng
 *
 */
public class GetMaxValue {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] scores = new int[5];
		Scanner input = new Scanner(System.in);
		System.out.println("请输入五名同学的成绩");
		for(int i = 0; i < scores.length; i++)
		{
			scores[i] = input.nextInt();
		}
		
		int max = scores[0];
		for(int i = 1; i < scores.length;i++)
		{
			if(scores[i] > max)
			{
				max  = scores[i];
			}
		}
		System.out.print("考试最高分是 "+max);
	}
}
