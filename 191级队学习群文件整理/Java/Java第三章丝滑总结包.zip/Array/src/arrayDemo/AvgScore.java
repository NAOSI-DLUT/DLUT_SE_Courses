/**
 * 
 */
package arrayDemo;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class AvgScore {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] scores = new int[5];
		int sum = 0;	// 成绩总和
		Scanner input = new Scanner(System.in);
		System.out.print("请输入五名同学的成绩");
		for(int i = 0; i < scores.length; i++)
		{
			scores[i] = input.nextInt();
			sum += scores[i];
		}
		double avg = ((double)sum)/scores.length;
		System.out.println("全班的平均分是"+avg);
	}
}
