/**
 * 
 */
package arrayDemo;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class InsertArrayDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] list = {99,85,82,63,60};	// 数组的长度是固定的，是静态定义的
		System.out.print("请输入你要插入的数值：");
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		int index = list.length - 1;
		for(int i = 0; i< list.length ; i++)
		{
			if(num > list[i])
			{
				index = i;
				break;
			}
		}
		// 原index位置及后面所有数据都要整体后移
		for(int i = list.length - 1; i>index; i--)
		{
			list[i] = list[i - 1];
		}
		
		list[index] = num;
		
		for(int listNum: list)
		{
			System.out.print(listNum+"\t");
		}
	}

}
