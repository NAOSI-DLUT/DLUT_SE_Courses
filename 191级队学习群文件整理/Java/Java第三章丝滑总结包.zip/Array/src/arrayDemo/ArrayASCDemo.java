/**
 * 
 */
package arrayDemo;

import java.util.Scanner;
import java.util.Arrays;
/**
 * @author jiangpeifeng
 *
 */
public class ArrayASCDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] scores = new int[5];
		Scanner input = new Scanner(System.in);
		System.out.println("请输入五名同学的成绩");
		for(int i = 0; i < scores.length; i++)
		{
			scores[i] = input.nextInt();
		}
		Arrays.sort(scores);  	// 对数组进行升序排列
		System.out.println("按照升序排序的数组是：");
		/*for(int i = 0; i < scores.length; i++)
		{
			System.out.print(scores[i]+" ");
		}*/
		for(int i: scores)
		{
			// 增强型for循环
			System.out.print(i + " ");
		}
	}
}
