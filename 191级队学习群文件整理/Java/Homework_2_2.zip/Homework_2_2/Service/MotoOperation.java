package Service;

import Model.Bus;
import Model.Car;
import Model.MotoVehicle;
import java.util.*;


/**
 * 汽车业务
 */
public class MotoOperation 
{	
	/*
	LinkedList泛型应用
	*/
	LinkedList<MotoVehicle> motoVehicles = new LinkedList<MotoVehicle>();
	public void initLinkedList()
	{
		System.out.println("\033[31mLinked List Initialization:\n");
		Car car0 = new Car("京NY28588", "宝马", "X6",800);
		Car car1 = new Car("京CNY3284", "宝马", "550i",600);
		Car car2 = new Car("京NT37465", "别克", "林荫大道",300);
		Car car3 = new Car("京NT96968", "别克", "GL8",600);
		Bus bus1 = new Bus("京6566754", "金杯", 16,800);
		Bus bus2 = new Bus("京8696997", "金龙", 16,800);
		Bus bus3  = new Bus("京9696996", "金杯", 34,1500);
		Bus bus4 = new Bus("京8696998", "金龙", 34,1500);
		motoVehicles.add(car0);
		motoVehicles.add(car2);
		motoVehicles.add(car3);
		motoVehicles.add(car1);
		motoVehicles.add(bus1);
		motoVehicles.add(bus2);
		motoVehicles.add(bus3);
		motoVehicles.add(bus4);
		//获取机车数量
		System.out.println("共有"+motoVehicles.size()+"辆机车。");
		System.out.println("分别是：");
		//使用Iterator接口遍历机车集合
		Iterator<MotoVehicle> iterator = motoVehicles.iterator();
		while(iterator.hasNext()){		
			MotoVehicle moto = iterator.next();
			System.out.println(moto.getBrand()+ "\t"+ moto.getPerRent()+"\t"+moto.getVehicleId());
		}
		System.out.println("forEach循环输出：");
		for(MotoVehicle moto : motoSet){
			System.out.println(moto.getBrand()+ "\t"+ moto.getPerRent()+"\t"+moto.getVehicleId());
		}
	}

	// ArrayList 泛型应用
	List<MotoVehicle> motoList = new ArrayList();
	public void initArrayList()
	{
		System.out.println("\033[31mArrayList Initialization:\n");
		Car car1 = new Car("京NY28588", "宝马", "X6",800);
		Car car2 = new Car("京CNY3284", "宝马", "550i",600);
		Car car3 = new Car("京NT37465", "别克", "林荫大道",300);
		Car car4 = new Car("京NT96968", "别克", "GL8",600);
		Bus bus1 = new Bus("京6566754", "金杯", 16,800);
		Bus bus2 = new Bus("京8696997", "金龙", 16,800);
		Bus bus3  = new Bus("京9696996", "金杯", 34,1500);
		Bus bus4 = new Bus("京8696998", "金龙", 34,1500);
		motoList.add(car1);
		motoList.add(car2);
		motoList.add(car3);
		motoList.add(car4);
		motoList.add(bus1);
		motoList.add(bus2);
		motoList.add(bus3);
		motoList.add(bus4);
		//获取机车数量
		System.out.println("共有"+motoList.size()+"辆机车。");
		System.out.println("分别是：");
		for(int i = 0; i < motoList.size();i++)
		{		
			MotoVehicle moto = motoList.get(i);
			System.out.println(moto.getBrand()+ "\t"+ moto.getPerRent()+"\t"+moto.getVehicleId());
		}
		System.out.println("forEach循环输出：");
		for(MotoVehicle moto : motoSet)
		{
			System.out.println(moto.getBrand()+ "\t"+ moto.getPerRent()+"\t"+moto.getVehicleId());
		}
	}

	// HashSet 泛型应用
	Set<MotoVehicle> motoSet = new HashSet<MotoVehicle>();
	public void initSet()
	{
		System.out.println("\033[31mHashSet Initialization:\n");
		Car car1 = new Car("京NY28588", "宝马", "X6",800);
		Car car2 = new Car("京CNY3284", "宝马", "550i",600);
		Car car3 = new Car("京NT37465", "别克", "林荫大道",300);
		Car car4 = new Car("京NT96968", "别克", "GL8",600);
		Bus bus1 = new Bus("京6566754", "金杯", 16,800);
		Bus bus2 = new Bus("京8696997", "金龙", 16,800);
		Bus bus3  = new Bus("京9696996", "金杯", 34,1500);
		Bus bus4 = new Bus("京8696998", "金龙", 34,1500);
		motoList.add(car1);
		motoList.add(car2);
		motoList.add(car3);
		motoList.add(car4);
		motoList.add(bus1);
		motoList.add(bus2);
		motoList.add(bus3);
		motoList.add(bus4);
		//获取机车数量
		System.out.println("共有"+motoSet.size()+"辆机车。");
		System.out.println("分别是：");
		//使用Iterator接口遍历机车集合
		Iterator<MotoVehicle> iterator = motoSet.iterator();
		while(iterator.hasNext())
		{		
			MotoVehicle moto = iterator.next();
			System.out.println(moto.getBrand()+ "\t"+ moto.getPerRent()+"\t"+moto.getVehicleId());
		}
		System.out.println("forEach循环输出：");
		for(MotoVehicle moto : motoSet){
			System.out.println(moto.getBrand()+ "\t"+ moto.getPerRent()+"\t"+moto.getVehicleId());
		}
	} 

	

	/**
	 * 租赁汽车 
	 * @return 汽车
	 */
	public MotoVehicle motoLeaseOut(String brand,String type,int seat){
		MotoVehicle moto=null;
		for (MotoVehicle motos : motoVehicles) {
			if(motos instanceof Car){
				Car car=(Car)motos;
				if(car.getBrand().equals(brand)&&car.getType().equals(type)){
					moto=car;
					break;
				}
			}else{
				Bus bus=(Bus)motos;
				if(bus.getBrand().equals(brand)&&bus.getSeatCount()==seat){
					moto=bus;
					break;
				}
			}
		}
		return moto;//返回一个汽车对象
	}
}
