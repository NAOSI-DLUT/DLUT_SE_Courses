package Model;
public interface Interface
{
   
}