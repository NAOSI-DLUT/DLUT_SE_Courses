/**
 * 
 */
package 在线订餐系统;
import java.util.*;
/**
 * @author jiangpeifeng
 *
 */
public class OnlineOrderFood {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 定义数据：菜品信息
		String[] dishNames = {"红烧带鱼","鱼香肉丝","时令蔬菜"};	// 菜品名称
		double[] prices = {38.0,20.5,15};	// 菜品的单价
		int[] praiseNums = new int[3];	// 点赞数
		// 定义订单
		String[] names = new String[4];	// 订餐人名字
		String[] dishMsg = new String[4];	// 菜品名称+份数
		int [] times = new int[4];	// 送餐时间
		String[] addresses = new String[4];
		double[] sumPrices = new double[4];
		int[] states = new int[4];	// 订单状态：0：已预订，1：已完成
		// 初始化2个订单信息
		names[0] = "张三";
		dishMsg[0] = "红烧带鱼 2份";
		times[0] = 10;
		addresses[0] = "黄河路133号";
		sumPrices[0] = 76;	// 餐费如果大于50则免去配送费6元
		states[0] = 0; // 0表示已预订
		
		names[1] = "李四";
		dishMsg[1] = "鱼香肉丝 1份";
		times[1] = 13;
		addresses[1] = "长江路100号";
		sumPrices[1] = 26.5;	// 餐费如果大于50则免去配送费6元
		states[1] = 1; // 1表示已完成
		
		// 搭建项目的整体流程框架
		Scanner input = new Scanner(System.in);
		int num  = -1; // 用户输入0代表是返回，num表示返回时用户输入数字。0表示返回，1-6表示相应的操作
		System.out.println("==========欢迎使用在线订餐系统==========");
		// 记录用户是否退出：true退出，false不退出
		boolean flag = false;
		do
		{
			System.out.println("====================");
			System.out.println("1:我要订餐");
			System.out.println("2:查看订单");
			System.out.println("3:签收订单");
			System.out.println("4:删除订单");
			System.out.println("5:我要点赞");
			System.out.println("6:退出系统");
			System.out.println("====================");
			System.out.println("请输入上述相应的数字1-6进行选择");
			int choose = input.nextInt();
			switch(choose)
			{
			case 1:
				System.out.println("=====我要订餐=====");
				flag = false;
				// 订餐方法
				boolean isAdd =false;	// 判断订单是否已满（isAdd = false)，则不能够进行订餐操作
				for(int i =0; i < names.length; i++)
				{
					if(names[i]==null)	// 表示订单未满，还可以继续订餐
					{
						isAdd = true;
						System.out.print("请输入订餐人姓名：");
						String name = input.next();	// 订餐人姓名
						// 循环输出菜品信息
						System.out.println("序号\t菜品名\t单价\t点赞数");
						for(int j = 0; j < dishNames.length;j++)
						{
							String praise = (praiseNums[j]==0)? " ":(praiseNums[j]+"赞");
							System.out.println((j+1)+"\t"+dishNames[j]+"\t"+prices[i]+"\t"+praise);
						}
						// 用户根据菜品编号的输入进行选择判断
						System.out.print("请输入你要选择的菜品编号：");
						int no = input.nextInt();	// no表示选择的菜品编号
						while(no<1 || no>dishNames.length)
						{
							System.out.println("本店没有这个菜品，请重新选择");
							no = input.nextInt();
						}
						// 点菜份数选择
						System.out.print("请输入你要点这道菜的份数:");
						int number  = input.nextInt();	// number表示点餐份数
						// 输入送餐时间
						System.out.print("请输入送餐时间（送餐时间只能是10-20之间的整数）：");
						int time = input.nextInt();	// time表示送餐时间
						while(time < 10||time > 20)
						{
							System.out.print("送餐时间有问题，请输入10-20之间的整数");
							time = input.nextInt();
						}
						// 送餐地址
						System.out.print("请输入你要送餐的地址：");
						String address = input.next();	// address表示地址
						System.out.println("本次订餐成功了");
						// 打印输出用户订餐信息
						String dishInfor = dishNames[no - 1]+" "+number+"份";
						System.out.println("您的订单是："+dishInfor);
						System.out.println("送餐时间是："+time+"点");
						double dishPrice = prices[no-1]*number;	// 单价*份数
						double peiSong = (dishPrice > 50)? 0: 6;	// 配送费
						double sumPrice = dishPrice+peiSong;	// 整个费用
						System.out.println("餐费是："+dishPrice+"元"+",配送费为"+peiSong+",总计费用"+sumPrice);
						
						// 把订餐信息添加到订单数组中，注意插入的位置
						names[i]= name;
						dishMsg[i] = dishInfor ;
						times[i] = time;
						addresses[i] = address;
						sumPrices[i] = sumPrice;
						break;
					}
				}
				if(!isAdd)
				{
					System.out.println("对不起订单已满，无法下单");
				}
				break;
			case 2:
				System.out.println("=====查看订单=====");
				// 查看订单方法
				System.out.println("序号\t订餐人\t菜品\t\t配送时间\t配送地址\t\t订餐金额\t订单状态");
				for(int i = 0; i< names.length; i++)
				{
					if(names[i]!= null)
					{
						// 输出数组里非空的定单信息
						String time = times[i] + "点";
						String state  =(states[i]==0)?"已预订":"已完成";
						System.out.println((i+1)+"\t"+names[i]+"\t"+dishMsg[i]+"\t"+time+"\t"+addresses[i]+"\t"+sumPrices[i]+"\t"+state);
					}
				}
				break;
			case 3:
				System.out.println("=====签收订单=====");
				// 签收订单方法
				// 签收之前需要进行判断：看一下订单是否存在，不存在不能签收；订单是已经完成状态，这时也不能签收
				// 只有订单编号存在并且是状态是预订状态，才能签收订单
				boolean isSign = false;	// 表示是否可以签收订单
				System.out.print("请输入要签收的订单编号:");
				int signNo = input.nextInt();	// sgnNo表示要签收的订单编号
				for(int i = 0; i< names.length;i++)
				{
					if((names[i]!=null) && (states[i]==0)  && i == (signNo - 1))
					{
						isSign = true;
						states[i] = 1;
						System.out.println("=====订单签收成功=====");
					}
				}
				if(!isSign)
				{
					System.out.println("您选择的订单不存在！");
				}
				break;
			case 4:
				System.out.println("=====删除订单=====");
				// 删除订单方法
				// 删除之前要进行判断定案编号是否存在，已经状态是完成的订单可以删除，状态为已预订的订单不可删除
				boolean isDelete = false;	// 判断是否可以删除
				System.out.print("请输入要删除订单的编号：");
				int deleteNumber = input.nextInt();	// number表示要删除订单的编号
				for(int i =0; i< names.length; i++)
				{
					if(names[i]!=null && states[i] == 0&& i == deleteNumber - 1)
					{
						//isDelete = true;
						//	订单信息，并且用户的订单编号已经找到， 并且订单状态为已预订，这时就不能删除
						System.out.print("订单未签收, 不能删除");
					}
					else if(names[i]!=null && states[i] == 1&& i == deleteNumber - 1)
					{
						isDelete = true;
						// 订单信息，并且用户输入的编号已经找到，并且状态为已删除，可以删除
						// 要找到删除的订单的位置下标：i，要把以后面的所有元素一次往前移动，最后一个数组元素要置空
						// 要注意的是往前移动的过程是把后一个元素复制前一个元素的过程
						for(int j = i; j< names.length-1;j++)
						{
							names[j]= names[j+1];
							dishMsg[j] = dishMsg[j+1];
							times[j] = times[j+1];
							addresses[j] = addresses[j+1];
							sumPrices[j] = sumPrices[j+1];
							states[j] = states[j+1];
						}
						// 最后一个元素置空然后才能腾地方下新订单
						names[names.length-1]= null;
						dishMsg[names.length-1] = null;
						times[names.length-1] = 0;
						addresses[names.length-1] = null;
						sumPrices[names.length-1] = 0;
						states[names.length-1] = 0;
						System.out.println("删除订单成功！");
					}
				}
				if(!isDelete)
				{
					System.out.println("您要删除的订单不存在！");
				}
				break;
			case 5:
				System.out.println("=====我要点赞=====");
				// 点赞方法
				// 循环输出菜品信息
				System.out.println("序号\t菜名\t单价\t点赞数");
				for(int j = 0; j< dishNames.length; j++)
				{
					String praise = (praiseNums[j]==0)? " ": praiseNums[j]+"赞";
					System.out.println((j+1)+"\t"+dishNames[j]+"\t"+prices[j]+"\t"+praise);
				}
				// 进行点赞
				System.out.print("请输入要点赞的菜品编号：");
				int praiseNo = input.nextInt();	// praiseNo表示点赞菜品编号
				while(praiseNo < 1|| praiseNo>dishNames.length)
				{
					System.out.print("本店没有此菜品，请重新输入菜品编号");
					praiseNo = input.nextInt();
				}
				praiseNums[praiseNo-1]++;
				System.out.println("点赞成功！");
				break;
			case 6:
				System.out.println("=====退出系统=====");
				// 退出方法
				flag = true;
				break;
			default:
				flag = true;
				break;
			}
			if(flag == false)	// if(!flag)
			{
				System.out.print("请输入0返回主界面");
				num = input.nextInt();
			}
			else
			{
				break;
			}
		}while(num == 0);	// 当num等于0时继续循环
		
	}

}
