package Package1;

import java.util.*;

import javax.swing.JOptionPane;
public class Test 
{ 
    public static void main(String[] args) 
    {
        Pet pet = new Pet();
        pickPetHome(pet);
		
    }

    // Pick a pet home
    public static void pickPetHome(Pet pet)
    {
        int alternative = 0;
        String output = "请输入您要领回家的宠物\n";
		output += "1--小狗勾\n";
		output += "2--小猫咪\n";
		String numString = JOptionPane.showInputDialog(null, output,"领养一只小可爱回家",JOptionPane.QUESTION_MESSAGE);
        alternative =  Integer.parseInt(numString);
        switch(alternative)
        {
            case 1: 
            String nameStringDog = JOptionPane.showInputDialog(null, "请输入您的宠物名字", "领养一只小可爱回家",JOptionPane.QUESTION_MESSAGE);
            String varietyStringDog = JOptionPane.showInputDialog(null,"请输入您的宠物品种","领养一只小可爱回家",JOptionPane.QUESTION_MESSAGE);
            pet = new Dog(nameStringDog, varietyStringDog);
            break;
            case 2:
            String nameStringCat = JOptionPane.showInputDialog(null, "请输入您的宠物名字","领养一只小可爱回家",JOptionPane.QUESTION_MESSAGE);
            String varietyStringCat = JOptionPane.showInputDialog(null, "请输入您的宠物品种","领养一只小可爱回家",JOptionPane.QUESTION_MESSAGE);
            pet = new Cat(nameStringCat, varietyStringCat);
            break;
            default:
            JOptionPane.showConfirmDialog(null, "输出有误！", "错误", JOptionPane.CANCEL_OPTION);
        }
        JOptionPane.showMessageDialog(null, "您成功领养了一只小可爱回家！", "领养一只小可爱回家", JOptionPane.INFORMATION_MESSAGE);
        displayPet(pet);
        tips(pet);
    }

    // Display the pet
    public static void displayPet(Pet pet)
    {
        if(pet instanceof Dog)
        {
            String output = "您家狗狗的信息如下：\n";
            output += "\n狗狗名字："+(((Dog)pet).getName());
            output += "\n狗狗品种："+(((Dog)pet).getVariety());
            output += "\n狗狗亲密度: " + (((Dog)pet).getIntimacy());
            output += "\n狗狗健康值："+(((Dog)pet).getHealthy());
            JOptionPane.showMessageDialog(null, output, "狗狗信息", JOptionPane.INFORMATION_MESSAGE);
        }
        else if(pet instanceof Cat)
        {
            String output = "您家喵喵的信息如下：\n";
            output += "喵喵名字："+(((Cat)pet).getName());
            output += "喵喵性别："+(((Cat)pet).getSex());
            output += "喵喵亲密度: " + (((Cat)pet).getIntimacy());
            output += "喵喵健康值："+(((Cat)pet).getHealthy());
            JOptionPane.showMessageDialog(null, output, "猫猫信息", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void tips(Pet pet)
   {
        int alternative = 0;
        boolean quit = false;
        do
        {
            String output = "快来陪陪小宠物们吧\n";
		    output += "1--陪宠物玩\n";
		    output += "2--陪宠物去医院\n";
            output += "3--退出";
		    String numString = JOptionPane.showInputDialog(null, output,"《宠物日记》",JOptionPane.QUESTION_MESSAGE);
            alternative =  Integer.parseInt(numString);
            switch(alternative)
            {
                case 1:
                if(pet instanceof Dog)
                {
                    ((Dog)pet).playWithPet();
                }
                else if(pet instanceof Cat)
                {
                    ((Cat)pet).playWithPet();
                }
                break;
                case 2: 
                if(pet instanceof Dog)
                {
                    ((Dog)pet).goToHospital();
                }
                else if(pet instanceof Cat)
                {
                    ((Cat)pet).goToHospital();
                }
                break;
                case 3:
                quit = true;
                break;
                default:
                break;
            }
        }while(!quit);
    }
}	

