package Package1;

import javax.swing.JOptionPane;

public class Dog extends Pet
{
    private String variety; // The variety of the dog

    public Dog()
    {

    }
     
    public Dog(String name, String variety) 
    {
        super(name);
        this.variety = variety;
    }
    
    @Override
    public void playWithPet() 
    {
        JOptionPane.showMessageDialog(null, "陪狗子玩飞盘……", "和狗子一起玩", JOptionPane.INFORMATION_MESSAGE);
        this.setIntimacy((getIntimacy())+5);
        this.setHealthy(getHealthy()-10);
        String output = "狗子玩的很开心\n";
        output += ("亲密度" + this.getIntimacy());
        JOptionPane.showMessageDialog(null, output, "和狗子一起玩",JOptionPane.INFORMATION_MESSAGE);
    }
    
    @Override
    public void goToHospital()
    {
        if(this.getHealthy()<30)
        {
            JOptionPane.showConfirmDialog(null, "您家的小狗子需要去医院了……","和狗子去医院",JOptionPane.OK_OPTION);  
            this.setHealthy(getHealthy()+50);
        }
        else
        {
            JOptionPane.showConfirmDialog(null, "您家的小狗子很健康","和狗子去医院",JOptionPane.OK_OPTION);  
        }
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }  
}
