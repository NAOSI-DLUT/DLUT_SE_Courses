package Package1;
import javax.swing.JOptionPane;

public  class Pet 
{
        private String name;    // 宠物名称   
        private int healthy;    // 宠物健康
        private int intimacy;   // 宠物亲密度  
    
        // Default constructor
        public Pet()
        {
        }

        // Construct a Pet
        public Pet(String name) 
        {
            this.name = name;
            this.healthy = 80;
            this.intimacy = 20;
        }

        // Play with the pet
        public  void playWithPet()
        {
            JOptionPane.showMessageDialog(null, "陪狗子玩飞盘……", "和狗子一起玩", JOptionPane.INFORMATION_MESSAGE);
            this.setIntimacy((getIntimacy())+5);
            this.setHealthy(getHealthy()-10);
            String output = "狗子玩的很开心\n";
            output += ("亲密度" + this.getIntimacy());
            JOptionPane.showMessageDialog(null, output, "和狗子一起玩",JOptionPane.INFORMATION_MESSAGE);
        }
        
        // Go to hospital with the pey
        public  void goToHospital()
        {
            if(this.getHealthy()<30)
        {
            JOptionPane.showConfirmDialog(null, "您家的小狗子需要去医院了……","和狗子去医院",JOptionPane.OK_OPTION);  
            this.setHealthy(getHealthy()+50);
        }
        else
        {
            JOptionPane.showConfirmDialog(null, "您家的小狗子很健康","和狗子去医院",JOptionPane.OK_OPTION);  
        }
        }

        // Get the intimacy of the pet
        public int getIntimacy() 
        {
            return intimacy;
        }

        // Set the intimacy of the pet
        public void setIntimacy(int intimacy) 
        {
            this.intimacy = intimacy;
        }
        
        // Get the name of the pet
        public String getName() 
        {
            return name;
        }

        // Set the name of the pet
        public void setName(String name) {
            this.name = name;
        }

        public int getHealthy() {
            return healthy;
        }
        public void setHealthy(int healthy) {
            this.healthy = healthy;
        }    
    }
    

