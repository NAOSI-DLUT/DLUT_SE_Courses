package Package1;

import javax.swing.JOptionPane;

public class Cat extends Pet
{
    private String sex; // The sex of the cat

    public Cat()
    {
        
    }
    // Construct a cat
    public Cat(String name, String sex) 
    {
        super(name);
        this.sex = sex;
    }

    @Override
    public void playWithPet() 
    {
        JOptionPane.showMessageDialog(null, "摸摸喵喵吧~", "和喵喵一起玩", JOptionPane.INFORMATION_MESSAGE);
        this.setIntimacy((getIntimacy())+5);
        this.setHealthy(getHealthy()-10);
        String output = "喵喵玩的很开心\n";
        output += ("亲密度" + this.getIntimacy());
        JOptionPane.showMessageDialog(null, output, "和喵喵一起玩",JOptionPane.INFORMATION_MESSAGE);
    }
    
    @Override
    public void goToHospital()
    {
        if(this.getHealthy()<30)
        {
            JOptionPane.showConfirmDialog(null, "您家的小喵喵需要去医院了……","和喵喵去医院",JOptionPane.OK_OPTION);  
            this.setHealthy(getHealthy()+50);
        }
        else
        {
            JOptionPane.showConfirmDialog(null, "您家的小喵喵很健康","和喵喵去医院",JOptionPane.OK_OPTION);  
        }
    }

    // Get the sex
    public String getSex() 
    {
        return sex;
    }

    // Set the sex
    public void setSex(String sex) 
    {
        this.sex = sex;
    }  
}
