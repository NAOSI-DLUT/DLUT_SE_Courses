# Chapter 1
每一章的introduction
1.2的俩程序需要背
1.5需要背
1.6看
1.7&1.8看
教材的名字和第一作者
RFC791 IP标准
RFC793 TCP标准
# Chapter 2
2.2 Big table
2.3TCP复习
2.6逐行读：图2.2 2.4状态转移图
2.7复杂 不要求
2.9端口号记一下
2.10要求
2.13了解一下都是什么协议
# Chapter 3 都要求
3.2
3.3 value-result
3.4 
3.6 3.7要求掌握原型
3.9 读写
# Chapter 4 全部要求
4.1的图背
figute 4.1-5 都要掌握
bind listen accept fork exec
4.8 concurrent servers
4.9 close
# Chapter 5 
5.10 wait和waitpid的区别
实验结果，实验分析从这里出
5.13不要，5.18不要
# Chapter 6
select
6.1
6.2 I/O models
6.3 相关的宏和意义
6.4 怎么用
6.5简单看
6.6认真看 与close的区别
6.7 6.8
6.12
# Chapter 7
7.1 里的方法
7.2 函数原型
图7.1 能看懂
上课讲过IP_TTL IP_HDRINCL(header include)
IP层的是IP层的。TCP是TCP层的level,optname，意义
7.3-5简单看
7.6里第一个 7.9里第一个
ftcl可以修改套接字option
7.12 summary看一下
概念题简单题可能直接从intro和sum里出
# Chapter 8
8.1的图
8.2 recvfrom and sendto
8.3-8.6 程序
8.10 summary
解释concurrent机制的设置和TCP的区别
# Chapter 11
简单了解一下四个函数关于DNS和服务的函数原型
# Chapter 17
I/O contrl可以对套接字的option进行修改读写
17.1 17.2
# Chapter 18
introduction
18.1 18.2
路由套接字怎么调用，family和type用什么
# Chapter 19
和18章要求一样
19.1 
# Chapter 25
in chap5 怎么调用signal，怎么signal action（参考ping）
# Chapter 26
基本概念，和进程的区别
# Chapter 28
traceroute原理
# Chapter 29
datalink introduction
29.1 2 3 4
简答题，编程题Snippet，程序分析
http echo 443
netstat怎么用 分析一下哪个是cli哪个是server
